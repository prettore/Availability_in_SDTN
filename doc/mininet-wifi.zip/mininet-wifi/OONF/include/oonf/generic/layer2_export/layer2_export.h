/*
 * layer2_export.h
 *
 *  Created on: 18.10.2017
 *      Author: rogge
 */

#ifndef _LAYER2_EXPORT_H_
#define _LAYER2_EXPORT_H_

#define OONF_LAYER2_EXPORT_SUBSYSTEM "layer2_export"

#endif /* _LAYER2_EXPORT_H_ */
