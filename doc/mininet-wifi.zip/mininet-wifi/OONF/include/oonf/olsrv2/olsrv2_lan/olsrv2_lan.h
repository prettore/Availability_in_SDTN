/*
 * old_lan.h
 *
 *  Created on: 18.10.2017
 *      Author: rogge
 */

#ifndef _OLSRV2_LAN_H_
#define _OLSRV2_LAN_H_

#define OONF_OLSRV2_LAN_SUBSYSTEM "olsrv2_lan"

#endif /* _OLSRV2_LAN_H_ */
