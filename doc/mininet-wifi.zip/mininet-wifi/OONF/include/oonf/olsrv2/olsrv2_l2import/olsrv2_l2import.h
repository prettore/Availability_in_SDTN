/*
 * olsrv2_l2import.h
 *
 *  Created on: 18.10.2017
 *      Author: rogge
 */

#ifndef _OLSRV2_L2IMPORT_H_
#define _OLSRV2_L2IMPORT_H_

#define OONF_OLSRV2_L2IMPORT_SUBSYSTEM "olsrv2_l2import"

#endif /* _OLSRV2_L2IMPORT_H_ */
